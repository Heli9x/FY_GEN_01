import pandas as pd
import json

class Sort:
    def __init__(self, data, is_file=True):
        if is_file:
            if data.endswith(".xlsx"):
                self.dataFrame = pd.read_excel(data)
            elif data.endswith(".csv"):
                self.dataFrame = pd.read_csv(data)
            else:
                raise ValueError("Unsupported file format try .xlsx or .csv")
        else:
            self.dataFrame = pd.DataFrame(data)

    def deleteColumn(self, columnName):
        """
        Deletes a column from the DataFrame if it exists.
        """
        if columnName in self.dataFrame.columns:
            self.dataFrame = self.dataFrame.drop(columns=[columnName])
        else:
            print(f"Column '{columnName}' does not exist.")
        return self.dataFrame

            
    def clean(self, columnName, numberOfDuplicateColumns):
        dupes = [col for col in self.dataFrame.columns if col.startswith(f"{columnName}.")]
        if numberOfDuplicateColumns is not None:
            dupes = dupes[:numberOfDuplicateColumns]

        self.dataFrame = self.dataFrame.drop(columns=dupes, errors="ignore")
        return self.dataFrame

    def rarefy(self, columnName: str):
        elements = self.dataFrame[columnName].unique().tolist()
        return elements

    def addUniqueIdColumn(self, columnName="UniqueID", start=1):
        """
        Adds a new column with unique numbered IDs to the DataFrame.
        By default, the column is named 'UniqueID' and starts from 1.
        """
        self.dataFrame[columnName] = range(start, start + len(self.dataFrame))
        return self.dataFrame

    def resortData(self, columnName:str):
        """
            This function creates an array of dataframes sorted according to the unique list of data provided.
            The Data in the filtered column elements must be members of column name in the originall data.
            if there's no relation, an error will occur or the data will not be rendered properly.
        """
        resortedData = {key: df for key, df in self.dataFrame.groupby(columnName)}
        return resortedData
    
    def exportSheets(self, data:dict, filename="final.xlsx",  singular=True):
        """
            This function exports a single work book, containing sheets created from the resorted data function as data frames.
            if xlsxwriter is missing or encounters an error, try to install it through pip manually. Command: 'pip install Xlsxwriter'.
        """
        with pd.ExcelWriter(filename, engine="xlsxwriter") as exporter:
            if singular:
                self.dataFrame.to_excel(exporter, sheet_name=self.dataFrame.columns[0], index=False)
            else:
                for sheet, df in data.items():
                    safe_name = str(sheet)[:31]
                    df.to_excel(exporter, sheet_name=safe_name, index=False)
        print("done")

    def exportJson(self, data:dict, filename="final.json"):
        json_data = {str(sheet): df.to_dict(orient="records") for sheet, df in data.items()}
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(json_data, f, ensure_ascii=False, indent=4)
        print("done")

    def scanDuplicateColumns(self):
        """
        Scans for duplicate columns in the DataFrame and returns a dictionary of duplicate column groups.
        Each group contains columns that have identical data.
        
        Returns:
            dict: A dictionary where keys are the first column name in each duplicate group,
                 and values are lists of column names that are duplicates of the key column.
        """
        duplicates = {}
        columns = self.dataFrame.columns
        
        # Compare each column with every other column
        for i in range(len(columns)):
            if columns[i] not in sum(duplicates.values(), []):  # Skip if column is already identified as a duplicate
                current_duplicates = []
                for j in range(i + 1, len(columns)):
                    # Compare the content of the columns
                    if self.dataFrame[columns[i]].equals(self.dataFrame[columns[j]]):
                        current_duplicates.append(columns[j])
                
                # If duplicates are found, add them to the dictionary
                if current_duplicates:
                    duplicates[columns[i]] = current_duplicates
        
        return duplicates

    def scanNumberedDuplicates(self):
        """
        Scans for columns that follow the pattern 'name', 'name.1', 'name.2', etc.
        These are typically created by pandas when reading files with duplicate column names.
        
        Returns:
            dict: A dictionary where keys are the base column names and values are lists
                 of all related numbered columns found (including the base name).
        """
        numbered_duplicates = {}
        columns = self.dataFrame.columns
        
        # Create a set of base names (without .n suffix)
        for col in columns:
            # Split on last occurrence of '.' to handle names that might contain dots
            parts = col.rsplit('.', 1)
            base_name = parts[0]
            
            # Check if the second part is a number
            if len(parts) == 1 or not parts[1].isdigit():
                continue
                
            # Initialize the list for this base name if not already present
            if base_name not in numbered_duplicates:
                # Check if the base column exists
                if base_name in columns:
                    numbered_duplicates[base_name] = [base_name]
                else:
                    numbered_duplicates[base_name] = []
            
            # Add the numbered column to the list
            numbered_duplicates[base_name].append(col)
        
        # Remove entries that don't have any numbered duplicates
        numbered_duplicates = {k: v for k, v in numbered_duplicates.items() if len(v) > 1}
        
        return numbered_duplicates
