from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from Sorter import Sort
from werkzeug.utils import secure_filename
import os 

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = 'Uploads'
app.config["DOWNLOAD_FOLDER"] = "Rendered"
CORS(app)

@app.route("/cje", methods=["POST"])
def convertFile():
    
    data = request.files.get('file')
    fileType = request.form.get('fileType')
    filename = secure_filename(request.form.get('filename'))

    if data:
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], f'{filename}.csv')
        data.save(filepath)
        
        dataHandler = Sort(f"Uploads/{filename}.csv")
        try:
            if fileType == "excel":
                dataHandler.exportSheets(dataHandler.resortData(dataHandler.dataFrame.columns[0]), f"Rendered/{filename}.xlsx")
            if fileType == "json":
                dataHandler.exportJson(dataHandler.resortData(dataHandler.dataFrame.columns[0]), f"Rendered/{filename}.json")
            dupes = dataHandler.scanNumberedDuplicates()
            if dataHandler.scanNumberedDuplicates == {}:
                dupes = dataHandler.scanDuplicateColumns

            print(dupes)
            return jsonify({"msg":" successful", "dupes": dupes})
        except:
            raise
            return jsonify({"msg": "Failed to convert the data"})

    else:
        return jsonify({"msg": "Data is invalid"})     

@app.route("/download/<path:filename>", methods=["GET"])
def downloadFile(filename):
    fullPath = os.path.join(app.root_path, app.config["DOWNLOAD_FOLDER"])
    return send_from_directory(directory=fullPath, path=filename, as_attachment=True)

app.run(port="8201", debug=True)